import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        crimson: {
          50:  "#fdf2f2",
          100: "#fce4e4",
          400: "#e05252",
          600: "#a01e1e",
          700: "#8B1A1A",
          800: "#6e1414",
          900: "#4d0e0e",
        },
        gold: {
          300: "#e8c97a",
          400: "#d4a843",
          500: "#C9A040",
          600: "#a07d28",
          700: "#7a5e18",
        },
        forest: {
          500: "#2d5444",
          600: "#1E3B2F",
          700: "#162c22",
          800: "#0e1e18",
        },
        cream: {
          50:  "#fdfbf7",
          100: "#F7F3EC",
          200: "#EDE6D6",
          300: "#ddd3be",
        },
        earth: {
          400: "#9b7c5a",
          500: "#7a5c3a",
          600: "#5c4228",
          700: "#3d2a16",
        },
      },
      fontFamily: {
        serif: ["'Playfair Display'", "Georgia", "serif"],
        sans:  ["'Source Sans 3'", "'Source Sans Pro'", "system-ui", "sans-serif"],
        mono:  ["'JetBrains Mono'", "monospace"],
      },
      backgroundImage: {
        "hero": "url('/images/hero.jpg')",
        "noise": "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E\")",
      },
      animation: {
        "fade-up":      "fadeUp 0.7s ease both",
        "fade-in":      "fadeIn 0.5s ease both",
        "slide-right":  "slideRight 0.6s ease both",
        "ken-burns":    "kenBurns 14s ease-out both",
        "scroll-line":  "scrollLine 2s ease-in-out infinite",
      },
      keyframes: {
        fadeUp:     { from: { opacity: "0", transform: "translateY(28px)" }, to: { opacity: "1", transform: "translateY(0)" } },
        fadeIn:     { from: { opacity: "0" }, to: { opacity: "1" } },
        slideRight: { from: { opacity: "0", transform: "translateX(-20px)" }, to: { opacity: "1", transform: "translateX(0)" } },
        kenBurns:   { from: { transform: "scale(1.08)" }, to: { transform: "scale(1)" } },
        scrollLine: { "0%,100%": { opacity: "0.4", transform: "scaleY(0.8)" }, "50%": { opacity: "1", transform: "scaleY(1)" } },
      },
      boxShadow: {
        "card":   "0 8px 40px rgba(26,18,8,0.10)",
        "card-lg":"0 20px 60px rgba(26,18,8,0.16)",
        "gold":   "0 4px 20px rgba(201,160,64,0.35)",
      },
    },
  },
  plugins: [],
};
export default config;
