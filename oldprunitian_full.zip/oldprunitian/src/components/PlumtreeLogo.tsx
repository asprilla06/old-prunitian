// PlumtreeLogo.tsx — SVG crest for Plumtree School / Oldprunitians
// Inspired by the school's heritage: crimson, gold, green

interface Props {
  className?: string;
}

export function PlumtreeLogo({ className = "w-14 h-14" }: Props) {
  return (
    <svg
      viewBox="0 0 80 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Plumtree School crest"
      role="img"
    >
      {/* Shield background */}
      <path
        d="M40 5 L72 18 L72 45 C72 60 55 72 40 77 C25 72 8 60 8 45 L8 18 Z"
        fill="#6e1414"
        stroke="#C9A040"
        strokeWidth="2"
      />
      {/* Inner shield highlight */}
      <path
        d="M40 11 L66 22 L66 45 C66 57 52 67 40 71 C28 67 14 57 14 45 L14 22 Z"
        fill="#8B1A1A"
      />
      {/* Gold cross bar */}
      <rect x="14" y="36" width="52" height="3" fill="#C9A040" opacity="0.7" />
      {/* Initials P S */}
      <text
        x="28"
        y="34"
        fontFamily="Georgia, serif"
        fontSize="13"
        fontWeight="bold"
        fill="#F7F3EC"
        textAnchor="middle"
        dominantBaseline="middle"
        letterSpacing="1"
      >P</text>
      <text
        x="52"
        y="34"
        fontFamily="Georgia, serif"
        fontSize="13"
        fontWeight="bold"
        fill="#F7F3EC"
        textAnchor="middle"
        dominantBaseline="middle"
        letterSpacing="1"
      >S</text>
      {/* Latin motto strip */}
      <path
        d="M14 45 L66 45 L66 55 L14 55 Z"
        fill="#C9A040"
        opacity="0.15"
      />
      <text
        x="40"
        y="52.5"
        fontFamily="Georgia, serif"
        fontSize="5.5"
        fill="#e8c97a"
        textAnchor="middle"
        dominantBaseline="middle"
        letterSpacing="0.5"
      >FORTIS ET FIDELIS</text>
      {/* Bottom acorn / plum motif */}
      <circle cx="40" cy="63" r="3.5" fill="#C9A040" opacity="0.7" />
      <line x1="40" y1="59.5" x2="40" y2="56" stroke="#C9A040" strokeWidth="1.2" opacity="0.7" />
      <path d="M37 56 Q40 53 43 56" stroke="#1E3B2F" strokeWidth="1.2" fill="none" opacity="0.8" />
      {/* Gold border dots at corners */}
      <circle cx="8"  cy="18" r="2" fill="#C9A040" />
      <circle cx="72" cy="18" r="2" fill="#C9A040" />
      <circle cx="40" cy="5"  r="2" fill="#C9A040" />
    </svg>
  );
}
