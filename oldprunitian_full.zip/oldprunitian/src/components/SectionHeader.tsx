// SectionHeader.tsx

interface Props {
  eyebrow?: string;
  title:    React.ReactNode;
  body?:    string;
  center?:  boolean;
  light?:   boolean;
}

export function SectionHeader({ eyebrow, title, body, center = true, light = false }: Props) {
  return (
    <div className={`reveal mb-14 ${center ? "text-center max-w-2xl mx-auto" : "max-w-2xl"}`}>
      {eyebrow && (
        <span className={`eyebrow ${light ? "text-gold-300" : "text-gold-500"}`}>
          {eyebrow}
        </span>
      )}
      <h2 className={`mt-2 ${light ? "text-white" : "text-charcoal"} text-balance`}>
        {title}
      </h2>
      <span className={`block w-14 h-0.5 my-4 ${center ? "mx-auto" : ""}`}
            style={{ background: "linear-gradient(90deg, transparent, #C9A040, transparent)" }} />
      {body && (
        <p className={`text-base leading-relaxed ${light ? "text-white/70" : "text-earth-500"}`}>
          {body}
        </p>
      )}
    </div>
  );
}
