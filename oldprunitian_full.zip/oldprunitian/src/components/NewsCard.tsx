import Image from "next/image";
import Link from "next/link";
import type { NewsArticle } from "@/lib/data";

interface Props { article: NewsArticle; featured?: boolean; }

export function NewsCard({ article, featured = false }: Props) {
  const date = new Date(article.date).toLocaleDateString("en-ZW", {
    year: "numeric", month: "long", day: "numeric",
  });

  const categoryColor: Record<string, string> = {
    "Events":          "badge-crimson",
    "Education":       "badge-forest",
    "Sport":           "badge-gold",
    "School":          "badge-forest",
    "Alumni Spotlight":"badge-crimson",
  };

  return (
    <article className={`card group ${featured ? "lg:flex" : "flex flex-col"}`}>
      {/* Image */}
      <div className={`relative overflow-hidden flex-shrink-0
                       ${featured ? "lg:w-2/5 h-64 lg:h-auto" : "h-52"}`}>
        <Image
          src={article.image}
          alt={article.title}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-105"
          sizes="(max-width:768px)100vw,(max-width:1024px)50vw,600px"
        />
        <div className="absolute top-3 left-3">
          <span className={`badge text-xs ${categoryColor[article.category] ?? "badge-gold"}`}>
            {article.category}
          </span>
        </div>
      </div>

      {/* Body */}
      <div className="p-6 flex flex-col flex-1">
        <div className="flex items-center gap-2 text-xs text-earth-400 mb-3">
          <time dateTime={article.date}>{date}</time>
          <span>·</span>
          <span>{article.author}</span>
        </div>

        <h3 className={`font-serif font-semibold leading-snug mb-3 group-hover:text-crimson-700
                         transition-colors duration-300 ${featured ? "text-2xl" : "text-xl"}`}>
          {article.title}
        </h3>

        <p className="text-sm text-earth-500 leading-relaxed flex-1 mb-4">{article.excerpt}</p>

        <div className="flex flex-wrap gap-2 mb-4">
          {article.tags.map((tag) => (
            <span key={tag}
                  className="text-xs px-2 py-0.5 bg-cream-200 text-earth-500 rounded-full">
              #{tag}
            </span>
          ))}
        </div>

        <Link
          href={`/news/${article.slug}`}
          className="text-xs font-bold tracking-widest uppercase text-crimson-700
                     hover:text-gold-600 transition-colors duration-200
                     flex items-center gap-2 mt-auto"
        >
          Read More →
        </Link>
      </div>
    </article>
  );
}
