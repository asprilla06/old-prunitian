import Link from "next/link";
import { SITE, NAV_LINKS } from "@/lib/data";
import { PlumtreeLogo } from "./PlumtreeLogo";

export function Footer() {
  return (
    <footer className="bg-charcoal text-white/65 pt-16 pb-0">
      <div className="container-px">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12
                        border-b border-white/8">

          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-3 mb-4 group">
              <PlumtreeLogo className="w-14 h-14" />
              <div>
                <div className="font-serif text-white text-xl font-semibold group-hover:text-gold-400 transition-colors duration-300">
                  Oldprunitians
                </div>
                <div className="text-xs font-sans tracking-widest uppercase text-gold-400">
                  Plumtree School, Zimbabwe
                </div>
              </div>
            </Link>
            <p className="text-sm leading-relaxed max-w-xs mt-4">
              {SITE.description}
            </p>
            <p className="text-xs italic text-gold-400 mt-3">"{SITE.tagline}"</p>
            {/* Social */}
            <div className="flex gap-3 mt-5">
              {[
                { label: "Facebook",  href: SITE.socials.facebook,  icon: "f" },
                { label: "Instagram", href: SITE.socials.instagram, icon: "📷" },
                { label: "WhatsApp",  href: SITE.socials.whatsapp,  icon: "💬" },
                { label: "X",         href: SITE.socials.twitter,   icon: "𝕏" },
              ].map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center
                             text-sm text-white/60 hover:border-gold-500 hover:text-gold-400
                             transition-all duration-300"
                >
                  {s.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h6 className="text-xs font-bold tracking-widest uppercase text-gold-400 mb-4">
              Navigation
            </h6>
            <ul className="space-y-2.5">
              {NAV_LINKS.map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="text-sm hover:text-gold-400 hover:pl-1 transition-all duration-200"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h6 className="text-xs font-bold tracking-widest uppercase text-gold-400 mb-4">
              Get in Touch
            </h6>
            <div className="space-y-3 text-sm">
              <div className="flex gap-2.5">
                <span className="text-gold-400 mt-0.5 flex-shrink-0">📍</span>
                <span>{SITE.address}</span>
              </div>
              <div className="flex gap-2.5">
                <span className="text-gold-400 flex-shrink-0">📞</span>
                <a href={`tel:${SITE.phone}`} className="hover:text-gold-400 transition-colors">
                  {SITE.phone}
                </a>
              </div>
              <div className="flex gap-2.5">
                <span className="text-gold-400 flex-shrink-0">✉</span>
                <a href={`mailto:${SITE.email}`} className="hover:text-gold-400 transition-colors break-all">
                  {SITE.email}
                </a>
              </div>
              <div className="flex gap-2.5">
                <span className="text-gold-400 flex-shrink-0">⏰</span>
                <span>Mon–Fri: 08:00–17:00 CAT</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="py-5 flex flex-col sm:flex-row items-center justify-between gap-3
                        text-xs text-white/35">
          <span>© {new Date().getFullYear()} The Oldprunitians Association. All rights reserved.</span>
          <span>Founded {SITE.founded} · Crafted with pride in Zimbabwe 🇿🇼</span>
          <div className="flex gap-4">
            <Link href="#" className="hover:text-gold-400 transition-colors">Privacy</Link>
            <Link href="#" className="hover:text-gold-400 transition-colors">Terms</Link>
            <Link href="#" className="hover:text-gold-400 transition-colors">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
