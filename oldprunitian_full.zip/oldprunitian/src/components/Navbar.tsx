"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { NAV_LINKS, SITE } from "@/lib/data";
import { PlumtreeLogo } from "./PlumtreeLogo";

export function Navbar() {
  const [scrolled,    setScrolled]    = useState(false);
  const [menuOpen,    setMenuOpen]    = useState(false);
  const [openDropdown,setOpenDropdown]= useState<string | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close menu on route change
  useEffect(() => { setMenuOpen(false); setOpenDropdown(null); }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-400
          ${scrolled
            ? "bg-charcoal/96 backdrop-blur-md shadow-lg py-3"
            : "bg-gradient-to-b from-black/50 to-transparent py-4"
          }`}
        aria-label="Main navigation"
        id="top"
      >
        <div className="container-px flex items-center justify-between">

          {/* Logo */}
          <Link
            href="/"
            className="flex items-center gap-3 group"
            aria-label={`${SITE.name} — Home`}
          >
            <PlumtreeLogo className="w-12 h-12 flex-shrink-0" />
            <div className="leading-none">
              <div className="font-serif text-white text-lg font-semibold tracking-wide leading-tight
                              group-hover:text-gold-300 transition-colors duration-300">
                Oldprunitians
              </div>
              <div className="text-xs font-sans tracking-widest uppercase text-gold-400 mt-0.5">
                Plumtree School
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <ul className="hidden lg:flex items-center gap-1" role="menubar">
            {NAV_LINKS.map((link) => (
              <li key={link.href} className="relative group" role="none">
                {link.children ? (
                  <>
                    <button
                      className="nav-link text-white/85 hover:text-gold-400 px-3 py-2 flex items-center gap-1"
                      aria-haspopup="true"
                      role="menuitem"
                    >
                      {link.label}
                      <svg className="w-3 h-3 transition-transform group-hover:rotate-180"
                           fill="none" viewBox="0 0 10 6">
                        <path d="M1 1l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                      </svg>
                    </button>
                    <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-56
                                    bg-charcoal border border-white/10 rounded-xl p-2
                                    opacity-0 invisible group-hover:opacity-100 group-hover:visible
                                    translate-y-2 group-hover:translate-y-0
                                    transition-all duration-300 shadow-card-lg"
                         role="menu">
                      {link.children.map((child) => (
                        <Link
                          key={child.href}
                          href={child.href}
                          className="block px-4 py-2.5 text-sm text-white/75 rounded-lg
                                     hover:bg-gold-500/15 hover:text-gold-400 transition-colors duration-200"
                          role="menuitem"
                        >
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  </>
                ) : (
                  <Link
                    href={link.href}
                    className="nav-link text-white/85 hover:text-gold-400 px-3 py-2 block"
                    role="menuitem"
                  >
                    {link.label}
                  </Link>
                )}
              </li>
            ))}
          </ul>

          {/* CTA */}
          <Link
            href="/contact"
            className="hidden lg:inline-flex btn btn-gold btn-sm"
          >
            Join the Association
          </Link>

          {/* Hamburger */}
          <button
            className="lg:hidden flex flex-col gap-1.5 p-1.5"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
          >
            <span className={`block w-6 h-0.5 bg-white transition-all duration-300
                              ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
            <span className={`block w-6 h-0.5 bg-white transition-all duration-300
                              ${menuOpen ? "opacity-0 scale-x-0" : ""}`} />
            <span className={`block w-6 h-0.5 bg-white transition-all duration-300
                              ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 bg-charcoal/98 flex flex-col justify-center px-8
                    transition-transform duration-500 ${menuOpen ? "translate-x-0" : "translate-x-full"}`}
        aria-hidden={!menuOpen}
      >
        <nav className="mt-16">
          {NAV_LINKS.map((link, i) => (
            <div key={link.href} className="border-b border-white/8">
              <Link
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="block font-serif text-3xl text-white/90 py-4
                           hover:text-gold-400 hover:pl-3 transition-all duration-300"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                {link.label}
              </Link>
              {link.children && (
                <div className="pl-4 pb-3 flex flex-col gap-1">
                  {link.children.map((child) => (
                    <Link
                      key={child.href}
                      href={child.href}
                      onClick={() => setMenuOpen(false)}
                      className="text-base text-white/50 hover:text-gold-400 py-1 transition-colors duration-200"
                    >
                      — {child.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
          <Link
            href="/contact"
            onClick={() => setMenuOpen(false)}
            className="btn btn-gold w-full justify-center mt-8"
          >
            Join the Association
          </Link>
        </nav>
      </div>
    </>
  );
}
