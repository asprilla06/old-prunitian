import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { SITE, STATS, NEWS_ARTICLES, COMMITTEE, KNOWLEDGE_BASE } from "@/lib/data";
import { SectionHeader } from "@/components/SectionHeader";
import { NewsCard } from "@/components/NewsCard";
import { PlumtreeLogo } from "@/components/PlumtreeLogo";

export const metadata: Metadata = {
  title: "The Oldprunitians Association — Plumtree School, Zimbabwe",
  description: SITE.description,
};

export default function HomePage() {
  const featuredNews  = NEWS_ARTICLES.filter((n) => n.featured).slice(0, 2);
  const latestNews    = NEWS_ARTICLES.slice(0, 3);

  return (
    <>
      {/* ── HERO ── */}
      <section
        className="relative min-h-screen flex flex-col items-center justify-center text-center
                   text-white overflow-hidden"
        aria-label="Hero banner"
      >
        {/* BG Image — Plumtree School 1 */}
        <div className="absolute inset-0 animate-ken-burns">
          <Image
            src="/images/hero.jpg"
            alt="Plumtree School main block aerial view"
            fill
            className="object-cover object-center"
            priority
            quality={90}
          />
        </div>
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b
                        from-black/40 via-black/55 to-black/75" />

        {/* Content */}
        <div className="relative z-10 max-w-4xl px-6 py-24 mt-10">
          {/* Crest */}
          <div className="flex justify-center mb-6 animate-fade-in" style={{ animationDelay:"0.1s" }}>
            <div className="p-3 rounded-full border border-gold-400/40 bg-black/20 backdrop-blur-sm">
              <PlumtreeLogo className="w-20 h-20" />
            </div>
          </div>

          {/* Badge */}
          <div className="animate-fade-up" style={{ animationDelay:"0.2s" }}>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full
                             border border-gold-400/40 bg-black/20 backdrop-blur-sm
                             text-xs font-bold tracking-widest uppercase text-gold-300">
              🇿🇼 Plumtree School · Est. {SITE.founded}
            </span>
          </div>

          <h1
            className="font-serif font-bold text-white mt-5 mb-4 text-balance animate-fade-up"
            style={{ animationDelay: "0.35s" }}
          >
            <em className="italic text-gold-300 not-italic">Fortis et Fidelis</em>
            <br />The Oldprunitians<br />Association
          </h1>

          <p
            className="text-base md:text-lg text-white/80 max-w-xl mx-auto mb-8 leading-relaxed animate-fade-up"
            style={{ animationDelay: "0.5s" }}
          >
            Connecting generations of proud Plumtree School alumni across Zimbabwe and the world. 
            Brave and faithful — always.
          </p>

          <div
            className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-up"
            style={{ animationDelay: "0.65s" }}
          >
            <Link href="/about" className="btn btn-gold btn-lg">Explore Our Story</Link>
            <Link href="/contact" className="btn btn-ghost btn-lg">Join the Association</Link>
          </div>
        </div>

        {/* Scroll cue */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10
                        flex flex-col items-center gap-2 animate-fade-in"
             style={{ animationDelay: "1.2s" }}>
          <span className="text-xs font-sans tracking-widest uppercase text-white/50">Scroll</span>
          <div className="w-px h-12 animate-scroll-line"
               style={{ background: "linear-gradient(to bottom, transparent, #C9A040, transparent)" }} />
        </div>

        {/* Stats bar */}
        <div className="absolute bottom-0 left-0 right-0 bg-black/50 backdrop-blur-md
                        border-t border-white/8 py-4 hidden md:block z-10">
          <div className="container-px flex justify-center gap-0">
            {STATS.map((stat, i) => (
              <div key={stat.label}
                   className={`flex flex-col items-center px-10
                               ${i < STATS.length - 1 ? "border-r border-white/15" : ""}`}>
                <span className="font-serif text-3xl font-bold text-gold-400 leading-none">
                  {stat.num}
                </span>
                <span className="text-xs tracking-widest uppercase text-white/55 mt-1">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WELCOME STRIP ── */}
      <section className="section-sm bg-crimson-700">
        <div className="container-px text-center text-white">
          <p className="font-serif text-xl md:text-2xl italic text-gold-300 max-w-3xl mx-auto leading-relaxed">
            "Plumtree School does not merely educate. It forms character, forges brotherhood, and sends into the world 
            men and women who carry its red roofs in their hearts wherever they go."
          </p>
          <p className="mt-4 text-sm text-white/60 tracking-widest uppercase">
            — Cde. Musa Ndiweni, President, The Oldprunitians Association
          </p>
        </div>
      </section>

      {/* ── CAMPUS GALLERY STRIP ── */}
      <section className="section bg-cream-200" aria-label="Campus photographs">
        <div className="container-px">
          <SectionHeader
            eyebrow="Our Campus"
            title={<>The Heart of <em className="italic">Plumtree</em></>}
            body="Set in the beautiful Matabeleland South landscape, Plumtree School's iconic buildings have stood for over a century — a home to thousands of young Zimbabweans."
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 reveal">
            {[
              { src: "/images/hero.jpg",           alt: "Plumtree School aerial view — main block" },
              { src: "/images/campus-dusk.jpg",    alt: "Campus at dusk — panoramic view" },
              { src: "/images/campus-evening.jpg", alt: "Evening light over the main block" },
            ].map((img, i) => (
              <div key={i}
                   className="relative h-72 rounded-xl overflow-hidden group shadow-card
                              hover:shadow-card-lg transition-shadow duration-300"
                   data-delay={String(i * 100)}>
                <Image
                  src={img.src}
                  alt={img.alt}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                  sizes="(max-width:768px)100vw,33vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent
                                opacity-0 group-hover:opacity-100 transition-opacity duration-400"/>
              </div>
            ))}
          </div>
          <div className="text-center mt-8 reveal">
            <Link href="/gallery" className="btn btn-outline">View Full Gallery →</Link>
          </div>
        </div>
      </section>

      {/* ── ABOUT SNAPSHOT ── */}
      <section className="section bg-cream-100" aria-labelledby="about-heading">
        <div className="container-px">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Image stack */}
            <div className="relative h-96 reveal">
              <div className="absolute inset-0 rounded-2xl overflow-hidden shadow-card-lg">
                <Image
                  src="/images/campus-evening.jpg"
                  alt="Plumtree School evening"
                  fill
                  className="object-cover"
                  sizes="(max-width:1024px)100vw,50vw"
                />
              </div>
              {/* Floating badge */}
              <div className="absolute -bottom-5 -right-5 bg-crimson-700 text-white rounded-2xl
                              p-5 shadow-gold text-center">
                <div className="font-serif text-4xl font-bold text-gold-300 leading-none">122</div>
                <div className="text-xs font-bold tracking-widest uppercase mt-1">Years of Excellence</div>
              </div>
              <div className="absolute -top-4 -left-4 bg-charcoal text-white rounded-xl
                              px-5 py-3 shadow-lg text-xs font-bold tracking-widest uppercase">
                🏫 Est. 1902
              </div>
            </div>

            {/* Text */}
            <div className="reveal" data-delay="150">
              <span className="eyebrow">Who We Are</span>
              <h2 id="about-heading" className="mt-2 mb-4">
                A Bond Forged in <em className="italic text-crimson-700">Red Roofs &amp; Red Dust</em>
              </h2>
              <span className="gold-divider-left" />
              <p className="text-earth-500 leading-relaxed mb-4">
                The Oldprunitians Association brings together former students of Plumtree School — 
                one of Zimbabwe's most distinguished boarding schools — in a spirit of mutual support, 
                shared memory, and continued service to the institution that shaped us.
              </p>
              <p className="text-earth-500 leading-relaxed mb-6">
                From Bulawayo to London, Sydney to Harare, our members carry Plumtree's values of 
                academic excellence, athletic discipline and moral courage into every sphere of life.
              </p>
              <div className="grid grid-cols-2 gap-4 mb-8">
                {[
                  { icon: "🎓", text: "Annual bursary fund for current students" },
                  { icon: "🏗", text: "Infrastructure development at school" },
                  { icon: "🤝", text: "Career mentorship for school leavers" },
                  { icon: "🏆", text: "Sports and cultural events annually" },
                ].map((item) => (
                  <div key={item.text} className="flex items-start gap-3 text-sm text-earth-500">
                    <span className="text-xl flex-shrink-0">{item.icon}</span>
                    <span>{item.text}</span>
                  </div>
                ))}
              </div>
              <Link href="/about" className="btn btn-crimson">Our Full Story →</Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── HISTORY TIMELINE (mini) ── */}
      <section className="section bg-charcoal" aria-labelledby="timeline-heading">
        <div className="container-px">
          <SectionHeader
            eyebrow="Our Heritage"
            title={<>Over a Century of <em className="italic text-gold-400">History</em></>}
            body="From colonial boarding school to Zimbabwe's proudest educational institution — the Plumtree story spans 12 decades."
            light
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {KNOWLEDGE_BASE.history.slice(0, 4).map((item, i) => (
              <div key={item.year}
                   className="reveal bg-white/5 border border-white/8 rounded-xl p-6
                              hover:border-gold-500/40 hover:bg-white/8 transition-all duration-300"
                   data-delay={String(i * 80)}>
                <div className="font-serif text-3xl font-bold text-gold-400 mb-3">{item.year}</div>
                <p className="text-sm text-white/65 leading-relaxed">{item.event}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-10 reveal">
            <Link href="/knowledge-base#history" className="btn btn-outline">
              Full History →
            </Link>
          </div>
        </div>
      </section>

      {/* ── NOTABLE ALUMNI ── */}
      <section className="section bg-cream-100" aria-labelledby="alumni-heading">
        <div className="container-px">
          <SectionHeader
            eyebrow="Distinguished Old Boys"
            title={<>Notable <em className="italic text-crimson-700">Oldprunitians</em></>}
            body="Plumtree School has produced leaders in politics, medicine, law, sport and the arts."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {KNOWLEDGE_BASE.notableAlumni.map((alum, i) => (
              <div key={alum.name}
                   className="reveal card p-6"
                   data-delay={String(i * 70)}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-crimson-700 flex items-center justify-center
                                  text-gold-300 font-serif font-bold flex-shrink-0">
                    {alum.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-semibold text-charcoal text-sm">{alum.name}</div>
                    <div className="text-xs text-gold-500">{alum.field} · {alum.year}</div>
                  </div>
                </div>
                <p className="text-sm text-earth-500 leading-relaxed">{alum.note}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-8 reveal">
            <Link href="/knowledge-base#alumni" className="btn btn-outline">All Notable Alumni →</Link>
          </div>
        </div>
      </section>

      {/* ── FULL WIDTH CAMPUS PHOTO ── */}
      <section className="relative h-96 md:h-[500px] overflow-hidden" aria-hidden="true">
        <Image
          src="/images/campus-dusk.jpg"
          alt="Plumtree School campus at dusk"
          fill
          className="object-cover object-center"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-r
                        from-charcoal/90 via-charcoal/50 to-transparent" />
        <div className="absolute inset-0 flex items-center">
          <div className="container-px max-w-lg">
            <span className="eyebrow text-gold-300">Our Motto</span>
            <h2 className="text-white mt-2 mb-4 text-4xl md:text-5xl">
              <em className="italic text-gold-300">Fortis</em><br />et Fidelis
            </h2>
            <p className="text-white/75 text-base leading-relaxed mb-6">
              Brave and Faithful — the motto that has guided Plumtree's students for over 120 years.
            </p>
            <Link href="/about" className="btn btn-gold">Discover Our Values →</Link>
          </div>
        </div>
      </section>

      {/* ── COMMITTEE ── */}
      <section className="section bg-cream-200" aria-labelledby="committee-heading">
        <div className="container-px">
          <SectionHeader
            eyebrow="Executive Committee 2024"
            title={<>The People Who <em className="italic text-crimson-700">Serve You</em></>}
            body="Our volunteer executive committee works tirelessly to serve Oldprunitians and support Plumtree School."
          />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {COMMITTEE.map((member, i) => (
              <div key={member.name}
                   className="reveal text-center group"
                   data-delay={String(i * 60)}>
                <div className="relative w-20 h-20 mx-auto mb-3">
                  <Image
                    src={member.avatar}
                    alt={member.name}
                    fill
                    className="rounded-full object-cover border-3 border-cream-200
                               group-hover:border-gold-400 transition-all duration-300"
                    sizes="80px"
                  />
                </div>
                <div className="text-sm font-semibold text-charcoal leading-tight">{member.name}</div>
                <div className="text-xs text-crimson-700 font-bold mt-1">{member.role}</div>
                <div className="text-xs text-earth-400 mt-0.5">{member.year}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── LATEST NEWS ── */}
      <section className="section bg-cream-100" aria-labelledby="news-heading">
        <div className="container-px">
          <div className="flex items-end justify-between mb-12">
            <SectionHeader
              eyebrow="Latest News"
              title={<>From the <em className="italic text-crimson-700">Oldprunitians</em></>}
              center={false}
            />
            <Link href="/news" className="hidden sm:inline-flex btn btn-outline btn-sm flex-shrink-0 mb-2">
              All News →
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {latestNews.map((article, i) => (
              <div key={article.id} className="reveal" data-delay={String(i * 80)}>
                <NewsCard article={article} />
              </div>
            ))}
          </div>
          <div className="text-center mt-8 sm:hidden reveal">
            <Link href="/news" className="btn btn-outline">All News →</Link>
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ── */}
      <section className="section-sm bg-crimson-700 relative overflow-hidden"
               aria-label="Call to action">
        <div className="absolute inset-0 opacity-5"
             style={{ backgroundImage: "url('/images/campus-evening.jpg')",
                      backgroundSize: "cover", backgroundPosition: "center" }} />
        <div className="container-px relative z-10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="text-white text-center lg:text-left">
              <span className="eyebrow text-gold-300">Are You an Oldprunitian?</span>
              <h2 className="text-white mt-2 text-3xl md:text-4xl">
                Join Your <em className="italic text-gold-300">Brothers &amp; Sisters</em>
              </h2>
              <p className="text-white/70 mt-3 max-w-md leading-relaxed">
                Register as an Oldprunitian member to access our network, events, 
                bursary fund and keep your connection to Plumtree alive.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 flex-shrink-0">
              <Link href="/contact" className="btn btn-gold btn-lg">Register Now</Link>
              <Link href="/about"   className="btn btn-ghost btn-lg">Learn More</Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
