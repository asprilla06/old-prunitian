import Link from "next/link";
import Image from "next/image";
import { PlumtreeLogo } from "@/components/PlumtreeLogo";

export default function NotFound() {
  return (
    <div className="relative min-h-screen flex items-center justify-center text-white overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <Image
          src="/images/campus-dusk.jpg"
          alt="Plumtree School"
          fill
          className="object-cover object-center"
          priority
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-br from-charcoal/90 via-charcoal/80 to-forest-700/70" />

      {/* Giant 404 */}
      <div
        className="absolute inset-0 flex items-center justify-center select-none pointer-events-none"
        aria-hidden="true"
      >
        <span
          className="font-serif font-bold text-white/6"
          style={{ fontSize: "clamp(10rem, 30vw, 22rem)", lineHeight: 1 }}
        >
          404
        </span>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-2xl">
        <div className="flex justify-center mb-6">
          <div className="p-3 rounded-full border border-gold-400/30 bg-black/20 backdrop-blur-sm">
            <PlumtreeLogo className="w-16 h-16" />
          </div>
        </div>

        <span className="eyebrow text-gold-300 block mb-4">Lost in the Plumtree Bush?</span>

        <h1 className="font-serif text-white text-5xl md:text-7xl font-bold mb-4">
          Page Not <em className="italic text-gold-300">Found</em>
        </h1>

        <p className="text-white/70 text-base md:text-lg leading-relaxed mb-8 max-w-lg mx-auto">
          Even the most experienced Plumtree guide sometimes takes a wrong turn.
          The page you're looking for has moved, or perhaps never existed.
          Let us guide you back home.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-10">
          <Link href="/" className="btn btn-gold btn-lg">
            ← Back to Home
          </Link>
          <Link href="/contact" className="btn btn-ghost btn-lg">
            Contact Us
          </Link>
        </div>

        {/* Quick links */}
        <div className="flex flex-wrap gap-3 justify-center">
          {[
            { label: "About",          href: "/about" },
            { label: "Knowledge Base", href: "/knowledge-base" },
            { label: "Gallery",        href: "/gallery" },
            { label: "News",           href: "/news" },
            { label: "Contact",        href: "/contact" },
          ].map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-xs font-bold tracking-widest uppercase px-4 py-2
                         border border-white/20 rounded-full text-white/60
                         hover:border-gold-400 hover:text-gold-300 transition-all duration-200"
            >
              {link.label}
            </Link>
          ))}
        </div>
      </div>

      {/* Bottom motto */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-center">
        <p className="text-xs text-white/35 tracking-widest uppercase font-sans italic">
          Fortis et Fidelis · Plumtree School est. 1902
        </p>
      </div>
    </div>
  );
}
