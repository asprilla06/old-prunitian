import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { NEWS_ARTICLES } from "@/lib/data";
import { NewsCard } from "@/components/NewsCard";

interface Props {
  params: { slug: string };
}

export function generateStaticParams() {
  return NEWS_ARTICLES.map((a) => ({ slug: a.slug }));
}

export function generateMetadata({ params }: Props): Metadata {
  const article = NEWS_ARTICLES.find((a) => a.slug === params.slug);
  if (!article) return { title: "Article Not Found" };
  return {
    title:       article.title,
    description: article.excerpt,
    openGraph: {
      title:  article.title,
      description: article.excerpt,
      images: [{ url: article.image, width: 800, height: 600, alt: article.title }],
    },
  };
}

export default function ArticlePage({ params }: Props) {
  const article = NEWS_ARTICLES.find((a) => a.slug === params.slug);
  if (!article) notFound();

  const related = NEWS_ARTICLES
    .filter((a) => a.id !== article.id && a.category === article.category)
    .slice(0, 3);
  const fallback = NEWS_ARTICLES.filter((a) => a.id !== article.id).slice(0, 3);
  const relatedArticles = related.length >= 2 ? related : fallback;

  const date = new Date(article.date).toLocaleDateString("en-ZW", {
    year: "numeric", month: "long", day: "numeric",
  });

  const categoryColor: Record<string, string> = {
    "Events":          "badge-crimson",
    "Education":       "badge-forest",
    "Sport":           "badge-gold",
    "School":          "badge-forest",
    "Alumni Spotlight":"badge-crimson",
  };

  return (
    <>
      {/* HERO */}
      <section className="relative h-[60vh] min-h-80 flex items-end text-white overflow-hidden">
        <div className="absolute inset-0">
          <Image src={article.image} alt={article.title} fill
                 className="object-cover object-center" priority />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/20" />
        <div className="relative z-10 container-px pb-10 pt-24 w-full">
          <nav aria-label="Breadcrumb"
               className="flex items-center gap-2 text-xs text-white/50 mb-4">
            <Link href="/" className="hover:text-gold-400 transition-colors">Home</Link>
            <span>/</span>
            <Link href="/news" className="hover:text-gold-400 transition-colors">News</Link>
            <span>/</span>
            <span className="text-white/30 truncate max-w-xs">{article.title}</span>
          </nav>
          <span className={`badge ${categoryColor[article.category] ?? "badge-gold"} mb-4`}>
            {article.category}
          </span>
          <h1 className="text-white text-3xl md:text-5xl max-w-3xl leading-tight">{article.title}</h1>
          <div className="flex items-center gap-4 mt-4 text-sm text-white/60">
            <time dateTime={article.date}>{date}</time>
            <span>·</span>
            <span>By {article.author}</span>
          </div>
        </div>
      </section>

      {/* ARTICLE BODY */}
      <article className="section bg-cream-100">
        <div className="container-px">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">

            {/* Main content */}
            <div className="lg:col-span-2">
              <p className="text-xl text-earth-500 leading-relaxed mb-6 font-serif italic border-l-4
                            border-gold-400 pl-5">
                {article.excerpt}
              </p>

              {/* Dummy full article body */}
              <div className="prose-custom space-y-5 text-earth-600 leading-relaxed">
                <p>
                  The Oldprunitians Association is proud to share this important update with all members
                  of our global community. As an organisation built on the values instilled at Plumtree
                  School — fortitude, faithfulness, and a deep sense of community — we believe in keeping
                  every Oldprunitian informed and connected to the life of the school and the association.
                </p>
                <p>
                  Plumtree School has always been more than an educational institution. It is a community,
                  a family, and for many of us, the place where the most formative years of our lives were
                  spent. The red tin roofs, the red Kalahari dust, the rugby fields at dawn — these are
                  images that stay with an Oldprunitian for a lifetime.
                </p>
                <h3 className="font-serif text-2xl text-charcoal mt-8 mb-3">What This Means for Our Community</h3>
                <p>
                  For the Oldprunitians Association, every development at Plumtree School is a matter of
                  collective pride and responsibility. Our committee has been actively engaged with the
                  school administration to ensure that the interests of both current students and alumni
                  are well represented.
                </p>
                <p>
                  We encourage all members — wherever you are in the world — to stay engaged. Share this
                  news with fellow Oldprunitians, contribute to our bursary fund, and if you are able to,
                  visit the school and remind the current students of the great tradition they are a part of.
                </p>
                <h3 className="font-serif text-2xl text-charcoal mt-8 mb-3">How You Can Help</h3>
                <p>
                  The association is always seeking volunteers, donors and mentors. If you would like to
                  contribute your skills, time or resources to any of our programmes, please reach out to
                  our secretary's office. No contribution is too small — every Oldprunitian has something
                  valuable to give back.
                </p>
                <blockquote className="border-l-4 border-crimson-700 pl-5 py-1 my-6">
                  <p className="font-serif italic text-xl text-charcoal">
                    "We are the product of Plumtree, and Plumtree is the product of us. 
                    That relationship is eternal."
                  </p>
                  <footer className="text-sm text-earth-400 mt-2">— Cde. Musa Ndiweni, OA President</footer>
                </blockquote>
                <p>
                  We thank you for your continued support and look forward to seeing many of you at our
                  upcoming events. Details will be shared in our newsletter and through our WhatsApp groups.
                </p>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mt-8 pt-8 border-t border-cream-300">
                {article.tags.map((tag) => (
                  <span key={tag}
                        className="text-xs px-3 py-1 bg-cream-200 text-earth-500 rounded-full border border-cream-300">
                    #{tag}
                  </span>
                ))}
              </div>

              {/* Share */}
              <div className="mt-6 flex items-center gap-4 flex-wrap">
                <span className="text-xs font-bold tracking-widest uppercase text-earth-400">Share:</span>
                {[
                  { label:"Facebook",  href:"https://facebook.com/sharer/sharer.php?u=",  icon:"f" },
                  { label:"Twitter/X", href:"https://twitter.com/intent/tweet?text=",     icon:"𝕏" },
                  { label:"WhatsApp",  href:"https://wa.me/?text=",                        icon:"💬" },
                ].map((s) => (
                  <a key={s.label}
                     href={`${s.href}${encodeURIComponent(article.title)}`}
                     target="_blank"
                     rel="noopener noreferrer"
                     aria-label={`Share on ${s.label}`}
                     className="w-9 h-9 rounded-full border border-cream-300 bg-cream-50
                                flex items-center justify-center text-sm text-earth-400
                                hover:border-gold-400 hover:text-gold-500 transition-all duration-200">
                    {s.icon}
                  </a>
                ))}
              </div>
            </div>

            {/* Sidebar */}
            <aside className="space-y-6">
              {/* Author card */}
              <div className="card p-5">
                <h5 className="text-xs font-bold tracking-widest uppercase text-gold-500 mb-4">Author</h5>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-crimson-700 flex items-center justify-center
                                  text-white font-serif font-bold flex-shrink-0 text-lg">
                    {article.author.charAt(0)}
                  </div>
                  <div>
                    <div className="font-semibold text-sm text-charcoal">{article.author}</div>
                    <div className="text-xs text-earth-400">Oldprunitians Association</div>
                  </div>
                </div>
              </div>

              {/* Recent articles */}
              <div className="card p-5">
                <h5 className="text-xs font-bold tracking-widest uppercase text-gold-500 mb-4">
                  More News
                </h5>
                <div className="space-y-4">
                  {NEWS_ARTICLES.filter((a) => a.id !== article.id).slice(0, 4).map((a) => (
                    <Link key={a.id} href={`/news/${a.slug}`}
                          className="flex gap-3 group">
                      <div className="relative w-14 h-14 rounded-lg overflow-hidden flex-shrink-0">
                        <Image src={a.image} alt={a.title} fill
                               className="object-cover transition-transform duration-300 group-hover:scale-105"
                               sizes="56px" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-charcoal leading-snug
                                      group-hover:text-crimson-700 transition-colors duration-200 line-clamp-2">
                          {a.title}
                        </p>
                        <time className="text-xs text-earth-400 mt-0.5 block" dateTime={a.date}>
                          {new Date(a.date).toLocaleDateString("en-ZW", { month:"short", day:"numeric", year:"numeric" })}
                        </time>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>

              {/* CTA */}
              <div className="bg-crimson-700 rounded-2xl p-6 text-white text-center">
                <div className="text-3xl mb-3">🎓</div>
                <h5 className="text-white font-serif mb-2">Are You an Oldprunitian?</h5>
                <p className="text-white/70 text-xs leading-relaxed mb-4">
                  Join the association and stay connected to your Plumtree family.
                </p>
                <Link href="/contact" className="btn btn-gold w-full justify-center btn-sm">
                  Join Now
                </Link>
              </div>
            </aside>
          </div>
        </div>
      </article>

      {/* RELATED */}
      <section className="section bg-cream-200">
        <div className="container-px">
          <h3 className="font-serif mb-8 text-center">
            More from the <em className="italic text-crimson-700">Oldprunitians</em>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relatedArticles.map((a, i) => (
              <div key={a.id} className="reveal" data-delay={String(i * 80)}>
                <NewsCard article={a} />
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link href="/news" className="btn btn-outline">All News →</Link>
          </div>
        </div>
      </section>
    </>
  );
}
