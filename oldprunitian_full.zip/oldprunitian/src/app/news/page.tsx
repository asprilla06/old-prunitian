import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { NEWS_ARTICLES } from "@/lib/data";
import { SectionHeader } from "@/components/SectionHeader";
import { NewsCard } from "@/components/NewsCard";

export const metadata: Metadata = {
  title: "Latest News",
  description: "News and updates from the Oldprunitians Association and Plumtree School, Zimbabwe.",
};

export default function NewsPage() {
  const featured = NEWS_ARTICLES.filter((a) => a.featured);
  const rest      = NEWS_ARTICLES.filter((a) => !a.featured);

  return (
    <>
      {/* PAGE HERO */}
      <section className="relative h-[50vh] min-h-72 flex items-center justify-center text-center text-white overflow-hidden">
        <div className="absolute inset-0">
          <Image src="/images/campus-evening.jpg" alt="Plumtree School" fill
                 className="object-cover" priority />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/60 to-black/80" />
        <div className="relative z-10 px-6 pt-20">
          <span className="eyebrow text-gold-300">News &amp; Updates</span>
          <h1 className="text-white mt-3 mb-3">
            Latest from <em className="italic text-gold-300">The Oldprunitians</em>
          </h1>
          <nav className="flex items-center justify-center gap-2 text-xs text-white/55">
            <Link href="/" className="hover:text-gold-400 transition-colors">Home</Link>
            <span>/</span><span>News</span>
          </nav>
        </div>
      </section>

      {/* FEATURED */}
      <section className="section bg-cream-100">
        <div className="container-px">
          <SectionHeader eyebrow="Featured Stories"
            title={<>Top <em className="italic text-crimson-700">Stories</em></>} />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-16">
            {featured.map((article, i) => (
              <div key={article.id} className="reveal" data-delay={String(i * 100)}>
                <NewsCard article={article} featured />
              </div>
            ))}
          </div>

          {/* All news */}
          <div className="border-t border-cream-300 pt-14">
            <SectionHeader eyebrow="All News"
              title={<>Recent <em className="italic text-crimson-700">Updates</em></>} />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {NEWS_ARTICLES.map((article, i) => (
                <div key={article.id} className="reveal" data-delay={String((i % 3) * 80)}>
                  <NewsCard article={article} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* NEWSLETTER */}
      <section className="section-sm bg-charcoal">
        <div className="container-px">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="text-white text-center lg:text-left">
              <span className="eyebrow text-gold-300">Stay Informed</span>
              <h2 className="text-white mt-2 text-3xl">
                Get News in Your <em className="italic text-gold-300">Inbox</em>
              </h2>
              <p className="text-white/60 mt-3 text-sm max-w-md leading-relaxed">
                Subscribe to the Oldprunitians quarterly newsletter — school updates, 
                alumni profiles, event invitations and more.
              </p>
            </div>
            <form
              className="flex flex-col sm:flex-row gap-0 w-full max-w-md rounded-full overflow-hidden
                         shadow-card-lg"
              onSubmit={(e) => e.preventDefault()}
            >
              <input
                type="email"
                placeholder="your@email.com"
                required
                className="flex-1 px-6 py-3.5 text-sm text-charcoal bg-white border-0
                           outline-none focus:ring-0 rounded-l-full"
                aria-label="Email address"
              />
              <button
                type="submit"
                className="px-6 py-3.5 bg-crimson-700 text-white text-xs font-bold
                           tracking-widest uppercase hover:bg-crimson-800 transition-colors
                           duration-200 flex-shrink-0 rounded-r-full"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>
    </>
  );
}
