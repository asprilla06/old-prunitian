import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { GALLERY_ITEMS } from "@/lib/data";
import { SectionHeader } from "@/components/SectionHeader";

export const metadata: Metadata = {
  title: "Photo Gallery",
  description: "Images of Plumtree School campus, events, alumni and the beautiful Matabeleland landscape.",
};

export default function GalleryPage() {
  const categories = ["All", ...Array.from(new Set(GALLERY_ITEMS.map((g) => g.category)))];

  return (
    <>
      {/* PAGE HERO */}
      <section className="relative h-[50vh] min-h-72 flex items-center justify-center text-center text-white overflow-hidden">
        <div className="absolute inset-0">
          <Image src="/images/campus-dusk.jpg" alt="Plumtree campus" fill
                 className="object-cover object-center" priority />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-black/55 to-black/80" />
        <div className="relative z-10 px-6 pt-20">
          <span className="eyebrow text-gold-300">Our Gallery</span>
          <h1 className="text-white mt-3 mb-3">
            Plumtree School <em className="italic text-gold-300">Through the Lens</em>
          </h1>
          <nav className="flex items-center justify-center gap-2 text-xs text-white/55">
            <Link href="/" className="hover:text-gold-400 transition-colors">Home</Link>
            <span>/</span><span>Gallery</span>
          </nav>
        </div>
      </section>

      {/* FEATURED — School Images */}
      <section className="section bg-cream-100">
        <div className="container-px">
          <SectionHeader eyebrow="Campus Photography"
            title={<>Our <em className="italic text-crimson-700">Beautiful Campus</em></>}
            body="Aerial and ground-level photography of Plumtree School's iconic buildings and grounds." />

          {/* Hero grid with 3 school photos */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 reveal">
            {[
              { src:"/images/hero.jpg",          alt:"Plumtree School — Aerial top-down view showing the main block quadrangle and chapel",     title:"Main Block — Aerial View" },
              { src:"/images/campus-dusk.jpg",   alt:"Plumtree School campus at dusk with palm trees and dramatic twilight sky",                title:"Campus at Dusk" },
              { src:"/images/campus-evening.jpg",alt:"Plumtree School main block at evening with beautiful warm light and village backdrop",     title:"Evening Golden Hour" },
            ].map((img) => (
              <div key={img.src}
                   className="relative group h-72 rounded-2xl overflow-hidden shadow-card-lg
                              hover:shadow-card-lg transition-all duration-300 cursor-zoom-in">
                <Image src={img.src} alt={img.alt} fill
                       className="object-cover transition-transform duration-700 group-hover:scale-105"
                       sizes="(max-width:768px)100vw,33vw" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-transparent
                                opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
                <div className="absolute bottom-0 left-0 right-0 p-4
                                translate-y-2 group-hover:translate-y-0
                                opacity-0 group-hover:opacity-100 transition-all duration-400">
                  <div className="text-white font-serif text-lg font-semibold">{img.title}</div>
                  <div className="text-gold-300 text-xs font-bold tracking-widest uppercase mt-1">Plumtree, Zimbabwe</div>
                </div>
              </div>
            ))}
          </div>

          {/* Wider description */}
          <div className="bg-cream-200 border border-cream-300 rounded-2xl p-8 text-center max-w-2xl mx-auto reveal">
            <div className="text-4xl mb-4">🏫</div>
            <h4 className="font-serif mb-3 text-charcoal">
              The Iconic <em className="italic text-crimson-700">Main Block</em>
            </h4>
            <p className="text-sm text-earth-500 leading-relaxed">
              Built in the Cape Dutch colonial style in the 1920s, Plumtree School's main block —
              with its distinctive red corrugated iron roof, white walls and elegant columned portico —
              is one of the most recognisable buildings in Matabeleland South. The central quadrangle
              garden with its ornamental fountain is a beloved gathering space for students and staff alike.
            </p>
          </div>
        </div>
      </section>

      {/* FULL GALLERY */}
      <section className="section bg-cream-200">
        <div className="container-px">
          <SectionHeader eyebrow="Photo Archive"
            title={<>Alumni & School <em className="italic text-crimson-700">Gallery</em></>} />

          {/* Filter buttons — pure HTML for static export */}
          <div className="flex flex-wrap gap-2 justify-center mb-10 reveal">
            {categories.map((cat) => (
              <button key={cat}
                      className={`px-4 py-2 text-xs font-bold tracking-widest uppercase rounded-full
                                  border transition-all duration-200 cursor-pointer
                                  ${cat === "All"
                                    ? "bg-crimson-700 border-crimson-700 text-white"
                                    : "border-cream-300 text-earth-500 bg-cream-50 hover:border-gold-400 hover:text-gold-500"
                                  }`}
                      data-category={cat}>
                {cat}
              </button>
            ))}
          </div>

          {/* Masonry-style grid */}
          <div className="columns-1 sm:columns-2 lg:columns-3 gap-4">
            {GALLERY_ITEMS.map((item, i) => (
              <div key={item.id}
                   className="reveal break-inside-avoid mb-4 group relative rounded-xl overflow-hidden
                              shadow-card hover:shadow-card-lg transition-all duration-300 cursor-pointer"
                   data-delay={String((i % 3) * 80)}
                   data-gallery-category={item.category}>
                <div className="relative" style={{ paddingBottom: i % 3 === 0 ? "75%" : i % 3 === 1 ? "55%" : "65%" }}>
                  <Image src={item.image} alt={item.title} fill
                         className="object-cover transition-transform duration-700 group-hover:scale-105"
                         sizes="(max-width:640px)100vw,(max-width:1024px)50vw,33vw" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent
                                  opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
                  <div className="absolute bottom-0 left-0 right-0 p-4
                                  translate-y-2 group-hover:translate-y-0
                                  opacity-0 group-hover:opacity-100 transition-all duration-500">
                    <span className="badge-gold badge text-xs mb-2">{item.category}</span>
                    <div className="text-white font-serif text-base font-semibold leading-snug">
                      {item.title}
                    </div>
                    <div className="text-white/60 text-xs mt-1">{item.year}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SHARE CTA */}
      <section className="section-sm bg-charcoal text-center">
        <div className="container-px text-white">
          <h3 className="text-white mb-3">Have Old Photos to Share?</h3>
          <p className="text-white/60 max-w-lg mx-auto mb-6 text-sm leading-relaxed">
            We are building the definitive photographic archive of Plumtree School history. 
            If you have old photographs, scanned documents or school memorabilia to share, 
            please get in touch with our archivist.
          </p>
          <Link href="/contact" className="btn btn-gold">Submit Photos →</Link>
        </div>
      </section>
    </>
  );
}
