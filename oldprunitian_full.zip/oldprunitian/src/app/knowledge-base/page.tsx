import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { KNOWLEDGE_BASE } from "@/lib/data";
import { SectionHeader } from "@/components/SectionHeader";

export const metadata: Metadata = {
  title: "Knowledge Base",
  description: "Plumtree School history, notable alumni, traditions, houses and sporting legacy.",
};

export default function KnowledgeBasePage() {
  return (
    <>
      {/* PAGE HERO */}
      <section className="relative h-[50vh] min-h-72 flex items-center justify-center text-center text-white overflow-hidden">
        <div className="absolute inset-0">
          <Image src="/images/campus-dusk.jpg" alt="Plumtree campus at dusk" fill
                 className="object-cover" priority />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-black/55 to-black/75" />
        <div className="relative z-10 px-6 pt-20">
          <span className="eyebrow text-gold-300">Knowledge Base</span>
          <h1 className="text-white mt-3 mb-3">
            School History &amp; <em className="italic text-gold-300">Heritage</em>
          </h1>
          <nav className="flex items-center justify-center gap-2 text-xs text-white/55">
            <Link href="/" className="hover:text-gold-400 transition-colors">Home</Link>
            <span>/</span><span>Knowledge Base</span>
          </nav>
        </div>
      </section>

      {/* QUICK LINKS */}
      <div className="bg-charcoal border-b border-white/8 sticky top-[68px] z-40">
        <div className="container-px flex gap-0 overflow-x-auto">
          {["history","alumni","traditions","sports"].map((id) => (
            <a key={id} href={`#${id}`}
               className="flex-shrink-0 px-5 py-3.5 text-xs font-bold tracking-widest uppercase
                          text-white/60 hover:text-gold-400 border-b-2 border-transparent
                          hover:border-gold-400 transition-all duration-200">
              {id === "alumni" ? "Notable Alumni" :
               id === "traditions" ? "Houses & Traditions" :
               id === "sports" ? "Sports Legacy" : "History"}
            </a>
          ))}
        </div>
      </div>

      {/* HISTORY TIMELINE */}
      <section className="section bg-cream-100" id="history" aria-labelledby="history-heading">
        <div className="container-px">
          <SectionHeader eyebrow="School Timeline"
            title={<>A Century of <em className="italic text-crimson-700">History</em></>}
            body="From its founding by the BSAC to a proudly Zimbabwean institution — twelve decades of Plumtree." />

          <div className="relative max-w-3xl mx-auto">
            {/* Vertical line */}
            <div className="absolute left-6 top-2 bottom-2 w-px bg-gold-400 opacity-30" />

            <div className="space-y-8 pl-16">
              {KNOWLEDGE_BASE.history.map((item, i) => (
                <div key={item.year}
                     className="reveal relative timeline-item"
                     data-delay={String(i * 60)}>
                  <div className="absolute -left-10 top-1 w-6 h-6 rounded-full bg-crimson-700
                                  border-2 border-gold-400 flex items-center justify-center
                                  shadow-gold flex-shrink-0" />
                  <div className="card p-5">
                    <div className="font-serif text-2xl font-bold text-gold-500 mb-1">{item.year}</div>
                    <p className="text-sm text-earth-500 leading-relaxed">{item.event}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* NOTABLE ALUMNI */}
      <section className="section bg-charcoal" id="alumni" aria-labelledby="alumni-heading">
        <div className="container-px">
          <SectionHeader eyebrow="Distinguished Old Boys"
            title={<>Notable <em className="italic text-gold-400">Oldprunitians</em></>}
            body="A proud record of Plumtree alumni who have distinguished themselves nationally and internationally." light />
          <div className="overflow-x-auto rounded-2xl border border-white/8">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/10 bg-white/5">
                  <th className="text-left px-5 py-4 text-xs font-bold tracking-widest uppercase text-gold-400">Name</th>
                  <th className="text-left px-5 py-4 text-xs font-bold tracking-widest uppercase text-gold-400">Year</th>
                  <th className="text-left px-5 py-4 text-xs font-bold tracking-widest uppercase text-gold-400">Field</th>
                  <th className="text-left px-5 py-4 text-xs font-bold tracking-widest uppercase text-gold-400">Achievement</th>
                </tr>
              </thead>
              <tbody>
                {KNOWLEDGE_BASE.notableAlumni.map((alum, i) => (
                  <tr key={alum.name}
                      className={`border-b border-white/5 hover:bg-white/5 transition-colors duration-200
                                  ${i % 2 === 0 ? "" : "bg-white/2"}`}>
                    <td className="px-5 py-4 font-semibold text-white/90">{alum.name}</td>
                    <td className="px-5 py-4 text-gold-400 font-mono">{alum.year}</td>
                    <td className="px-5 py-4">
                      <span className="badge-gold badge text-xs">{alum.field}</span>
                    </td>
                    <td className="px-5 py-4 text-white/60 text-xs leading-relaxed">{alum.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* HOUSES & TRADITIONS */}
      <section className="section bg-cream-100" id="traditions" aria-labelledby="traditions-heading">
        <div className="container-px">
          <SectionHeader eyebrow="Houses & Traditions"
            title={<>The <em className="italic text-crimson-700">Four Houses</em></>}
            body="House loyalty runs deep at Plumtree. Competition between the four houses shapes character, builds teamwork and creates memories." />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
            {KNOWLEDGE_BASE.houses.map((h, i) => {
              const colours: Record<string,string> = {
                Blue:"#1d4ed8",Red:"#b91c1c",Green:"#15803d",Yellow:"#ca8a04"
              };
              return (
                <div key={h.name}
                     className="reveal card p-6 border-l-4"
                     style={{ borderLeftColor: colours[h.colour] }}
                     data-delay={String(i*80)}>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 rounded-full"
                         style={{ backgroundColor: colours[h.colour] + "33",
                                  border: `2px solid ${colours[h.colour]}` }} />
                    <div>
                      <h4 className="text-charcoal">{h.name}</h4>
                      <span className="text-xs text-earth-400">Est. {h.established}</span>
                    </div>
                  </div>
                  <p className="text-sm text-earth-500 leading-relaxed">{h.description}</p>
                  <div className="mt-3 flex items-center gap-2">
                    <span className="text-xs font-bold tracking-wider uppercase text-earth-400">Colours:</span>
                    <div className="w-4 h-4 rounded-full border border-earth-200"
                         style={{ backgroundColor: colours[h.colour] }} />
                    <span className="text-xs text-earth-500">{h.colour}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Traditions */}
          <div className="mt-16">
            <h3 className="font-serif text-center mb-10">Cherished <em className="italic text-crimson-700">Traditions</em></h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { icon:"🏉", title:"Annual Sports Day", body:"The climax of the school calendar — four houses compete across athletics, rugby, cricket and swimming." },
                { icon:"🎭", title:"Dramatic Society", body:"Plumtree's DramSoc has produced outstanding productions for over 80 years, shaping future performers and orators." },
                { icon:"🌙", title:"Bonfire Night", body:"The end-of-term bonfire brings students, staff and the community together in a uniquely Plumtree tradition." },
                { icon:"📖", title:"Prize-Giving Day", body:"An annual celebration of academic excellence attended by parents, alumni and dignitaries from across Zimbabwe." },
                { icon:"🥁", title:"Dining Hall Drums", body:"The call to meals by the school drum — a simple but beloved ritual that connects generations of Plumtree students." },
                { icon:"🏔", title:"Matopo Day Hike", body:"Every year, students undertake a hike through the Matobo Hills — building endurance, resilience and appreciation for Zimbabwe's natural beauty." },
              ].map((t, i) => (
                <div key={t.title}
                     className="reveal card p-5"
                     data-delay={String(i*60)}>
                  <div className="text-3xl mb-3">{t.icon}</div>
                  <h5 className="font-serif mb-2">{t.title}</h5>
                  <p className="text-sm text-earth-500 leading-relaxed">{t.body}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SPORTS LEGACY */}
      <section className="section bg-crimson-700 relative overflow-hidden" id="sports">
        <div className="absolute inset-0 opacity-10">
          <Image src="/images/hero.jpg" alt="" fill className="object-cover" />
        </div>
        <div className="container-px relative z-10">
          <SectionHeader eyebrow="Sports Legacy"
            title={<>Champions on <em className="italic text-gold-300">Every Field</em></>}
            body="Plumtree School has produced national champions in rugby, cricket, chess, athletics and more." light />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { sport:"🏉 Rugby",    desc:"6× National Champions. Considered Zimbabwe's premier rugby school." },
              { sport:"🏏 Cricket",  desc:"Regular national finalists. Has produced 4 Zimbabwe Test cricketers." },
              { sport:"♟ Chess",    desc:"6 consecutive national championships. Premier chess school in Zimbabwe." },
              { sport:"🏃 Athletics",desc:"Multiple national athletics champions in sprints and field events." },
            ].map((s, i) => (
              <div key={s.sport}
                   className="reveal bg-white/8 border border-white/10 rounded-2xl p-6
                              text-white hover:bg-white/12 transition-colors duration-300"
                   data-delay={String(i*80)}>
                <div className="text-2xl mb-3">{s.sport}</div>
                <p className="text-sm text-white/70 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
