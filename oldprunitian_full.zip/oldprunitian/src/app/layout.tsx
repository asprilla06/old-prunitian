import type { Metadata } from "next";
import "../styles/globals.css";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { SITE } from "@/lib/data";

export const metadata: Metadata = {
  metadataBase: new URL("https://oldprunitians.org.zw"),
  title: {
    template: "%s | The Oldprunitians Association",
    default:  "The Oldprunitians Association — Plumtree School, Zimbabwe",
  },
  description: SITE.description,
  keywords: ["Plumtree School", "Oldprunitians", "Zimbabwe", "alumni", "boarding school", "Matabeleland"],
  authors: [{ name: "The Oldprunitians Association" }],
  creator: "Oldprunitians",
  openGraph: {
    type:        "website",
    locale:      "en_ZW",
    url:         "https://oldprunitians.org.zw",
    siteName:    "The Oldprunitians Association",
    title:       "The Oldprunitians Association — Plumtree School",
    description: SITE.description,
    images: [{
      url:    "/images/hero.jpg",
      width:  1280,
      height: 853,
      alt:    "Plumtree School Main Block — aerial view",
    }],
  },
  twitter: {
    card:        "summary_large_image",
    title:       "The Oldprunitians Association",
    description: SITE.description,
    images:      ["/images/hero.jpg"],
  },
  robots: {
    index:  true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  icons: {
    icon:  "/favicon.svg",
    apple: "/apple-touch-icon.png",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="min-h-screen flex flex-col bg-cream-100 text-earth-700 antialiased">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
        {/* Back to top */}
        <a
          href="#top"
          id="back-top"
          aria-label="Back to top"
          className="fixed bottom-6 right-6 z-50 w-11 h-11 rounded-full bg-crimson-700 text-white
                     flex items-center justify-center text-lg shadow-gold opacity-0 pointer-events-none
                     transition-all duration-300 hover:bg-crimson-800 hover:-translate-y-1"
        >
          ↑
        </a>
        <script dangerouslySetInnerHTML={{ __html: `
          // Back-to-top visibility
          (function(){
            var btn=document.getElementById('back-top');
            window.addEventListener('scroll',function(){
              var show=window.scrollY>500;
              btn.style.opacity=show?'1':'0';
              btn.style.pointerEvents=show?'auto':'none';
            },{passive:true});
            // Scroll reveal
            if('IntersectionObserver' in window){
              var obs=new IntersectionObserver(function(entries){
                entries.forEach(function(e,i){
                  if(e.isIntersecting){
                    var d=e.target.dataset.delay||0;
                    setTimeout(function(){e.target.classList.add('in-view');},+d);
                    obs.unobserve(e.target);
                  }
                });
              },{threshold:0.1,rootMargin:'0px 0px -40px 0px'});
              document.querySelectorAll('.reveal').forEach(function(el){obs.observe(el);});
            } else {
              document.querySelectorAll('.reveal').forEach(function(el){el.classList.add('in-view');});
            }
          })();
        `}} />
      </body>
    </html>
  );
}
