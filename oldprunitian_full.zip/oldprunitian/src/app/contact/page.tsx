import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { SITE } from "@/lib/data";
import { SectionHeader } from "@/components/SectionHeader";

export const metadata: Metadata = {
  title: "Contact Us",
  description: "Get in touch with the Oldprunitians Association — membership, events, bursary, and general enquiries.",
};

export default function ContactPage() {
  return (
    <>
      {/* PAGE HERO */}
      <section className="relative h-[50vh] min-h-72 flex items-center justify-center text-center text-white overflow-hidden">
        <div className="absolute inset-0">
          <Image src="/images/hero.jpg" alt="Plumtree School aerial" fill
                 className="object-cover object-top" priority />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-black/60 to-black/80" />
        <div className="relative z-10 px-6 pt-20">
          <span className="eyebrow text-gold-300">Get in Touch</span>
          <h1 className="text-white mt-3 mb-3">
            Contact the <em className="italic text-gold-300">Oldprunitians</em>
          </h1>
          <nav className="flex items-center justify-center gap-2 text-xs text-white/55">
            <Link href="/" className="hover:text-gold-400 transition-colors">Home</Link>
            <span>/</span><span>Contact</span>
          </nav>
        </div>
      </section>

      {/* CONTACT GRID */}
      <section className="section bg-cream-100">
        <div className="container-px">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">

            {/* Left: Info */}
            <div className="reveal lg:col-span-1">
              <span className="eyebrow">Reach Us</span>
              <h2 className="mt-2 mb-4 text-2xl md:text-3xl">
                We'd Love to <em className="italic text-crimson-700">Hear From You</em>
              </h2>
              <span className="gold-divider-left" />
              <p className="text-earth-500 text-sm leading-relaxed mb-8">
                Whether you're a newly registered Oldprunitian, a parent, or a well-wisher — 
                our secretary's office is always open to you.
              </p>

              <div className="space-y-5">
                {[
                  { icon:"📍", label:"School Address",  value: SITE.address },
                  { icon:"📞", label:"Phone",            value: SITE.phone, href: `tel:${SITE.phone}` },
                  { icon:"✉",  label:"Email",           value: SITE.email, href: `mailto:${SITE.email}` },
                  { icon:"⏰", label:"Office Hours",    value: "Mon–Fri: 08:00–17:00 CAT" },
                ].map((item) => (
                  <div key={item.label} className="flex gap-4 items-start">
                    <div className="w-11 h-11 flex-shrink-0 rounded-xl bg-cream-200 border border-cream-300
                                    flex items-center justify-center text-lg">
                      {item.icon}
                    </div>
                    <div>
                      <div className="text-xs font-bold tracking-widest uppercase text-gold-500 mb-0.5">
                        {item.label}
                      </div>
                      {item.href ? (
                        <a href={item.href}
                           className="text-sm text-earth-600 hover:text-crimson-700 transition-colors duration-200">
                          {item.value}
                        </a>
                      ) : (
                        <p className="text-sm text-earth-600">{item.value}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Map placeholder */}
              <div className="mt-8 rounded-2xl overflow-hidden border border-cream-300 shadow-card h-52 relative">
                <Image src="/images/campus-dusk.jpg" alt="Plumtree Town, Matabeleland South" fill
                       className="object-cover opacity-70" />
                <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                  <div className="text-center text-white">
                    <div className="text-3xl mb-2">📍</div>
                    <div className="text-sm font-bold">Plumtree Town</div>
                    <div className="text-xs text-white/70">Matabeleland South, Zimbabwe</div>
                    <a href="https://maps.google.com/?q=Plumtree+School+Zimbabwe"
                       target="_blank" rel="noopener noreferrer"
                       className="mt-3 inline-block btn btn-gold btn-sm text-xs">
                      Open in Maps
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Form */}
            <div className="reveal lg:col-span-2 bg-cream-50 border border-cream-200
                            rounded-2xl p-8 shadow-card" data-delay="150">
              <h3 className="font-serif mb-1">Send Us a Message</h3>
              <p className="text-earth-400 text-sm mb-6">
                We typically respond within 2–3 business days.
              </p>

              {/*
                Web3Forms integration:
                Replace YOUR_WEB3FORMS_KEY with your actual key from web3forms.com
                Form submissions will be sent to your email — no backend needed!
              */}
              <form
                action="https://api.web3forms.com/submit"
                method="POST"
                className="space-y-5"
                aria-label="Contact form"
              >
                {/* Web3Forms access key */}
                <input type="hidden" name="access_key" value="YOUR_WEB3FORMS_KEY_HERE" />
                <input type="hidden" name="subject" value="Oldprunitians Website Contact Form" />
                <input type="hidden" name="from_name" value="Oldprunitians Website" />
                {/* Honeypot */}
                <input type="checkbox" name="botcheck" className="hidden" style={{ display:"none" }} />

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="field-label" htmlFor="first_name">First Name *</label>
                    <input type="text" id="first_name" name="first_name" required
                           placeholder="e.g. Sipho" className="field" autocomplete="given-name" />
                  </div>
                  <div>
                    <label className="field-label" htmlFor="last_name">Last Name *</label>
                    <input type="text" id="last_name" name="last_name" required
                           placeholder="e.g. Nkomo" className="field" autocomplete="family-name" />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="field-label" htmlFor="email">Email Address *</label>
                    <input type="email" id="email" name="email" required
                           placeholder="you@example.com" className="field" autocomplete="email" />
                  </div>
                  <div>
                    <label className="field-label" htmlFor="phone">Phone / WhatsApp</label>
                    <input type="tel" id="phone" name="phone"
                           placeholder="+263 77 ..." className="field" autocomplete="tel" />
                  </div>
                </div>

                <div>
                  <label className="field-label" htmlFor="year_group">Year Group / Graduation Year</label>
                  <input type="text" id="year_group" name="year_group"
                         placeholder="e.g. 1995 — or 'Current Parent'" className="field" />
                </div>

                <div>
                  <label className="field-label" htmlFor="subject">Subject *</label>
                  <select id="subject" name="subject_select" required className="field">
                    <option value="">Select a topic…</option>
                    <option value="membership">Association Membership / Registration</option>
                    <option value="bursary">Bursary Fund Application or Donation</option>
                    <option value="events">Events &amp; Reunions</option>
                    <option value="infrastructure">School Infrastructure Project</option>
                    <option value="media">Media or Press Enquiry</option>
                    <option value="archive">Photo Archive Submission</option>
                    <option value="general">General Enquiry</option>
                  </select>
                </div>

                <div>
                  <label className="field-label" htmlFor="message">Your Message *</label>
                  <textarea id="message" name="message" required rows={5}
                            placeholder="Tell us how we can help you…"
                            className="field resize-y" />
                </div>

                <button type="submit"
                        className="btn btn-crimson w-full justify-center text-sm py-4">
                  Send Message →
                </button>

                <p className="text-center text-xs text-earth-400">
                  Your information is secure and will never be shared with third parties.
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* MEMBERSHIP ENQUIRY CARDS */}
      <section className="section bg-charcoal">
        <div className="container-px">
          <SectionHeader eyebrow="How Can We Help?"
            title={<>Quick <em className="italic text-gold-400">Enquiry Types</em></>}
            body="Select the type of enquiry that best matches your needs and we'll connect you with the right person." light />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              { icon:"🎓", title:"Join the OA",         body:"Register as an Oldprunitian member — free and open to all former students." },
              { icon:"💛", title:"Donate / Sponsor",    body:"Support the bursary fund or a specific school infrastructure project." },
              { icon:"🎉", title:"Events & Reunions",   body:"Find out about upcoming reunions, chapter meetings and social events." },
              { icon:"📚", title:"Mentorship Program",  body:"Offer or request career mentorship through our Oldprunitians mentorship network." },
            ].map((item, i) => (
              <div key={item.title}
                   className="reveal bg-white/5 border border-white/8 rounded-2xl p-6
                              hover:border-gold-500/40 hover:bg-white/8 transition-all duration-300
                              cursor-pointer"
                   data-delay={String(i*70)}>
                <div className="text-3xl mb-4">{item.icon}</div>
                <h5 className="text-white font-serif mb-2">{item.title}</h5>
                <p className="text-sm text-white/55 leading-relaxed">{item.body}</p>
                <Link href="#"
                      className="mt-4 inline-block text-xs font-bold tracking-widest uppercase
                                 text-gold-400 hover:text-gold-300 transition-colors duration-200">
                  Enquire →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
