import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { SITE, STATS, COMMITTEE, KNOWLEDGE_BASE } from "@/lib/data";
import { SectionHeader } from "@/components/SectionHeader";
import { PlumtreeLogo } from "@/components/PlumtreeLogo";

export const metadata: Metadata = {
  title: "About Us",
  description: "The story of Plumtree School and the Oldprunitians Association — 120+ years of excellence in Matabeleland, Zimbabwe.",
};

export default function AboutPage() {
  return (
    <>
      {/* PAGE HERO */}
      <section className="relative h-[55vh] min-h-80 flex items-center justify-center text-center
                          text-white overflow-hidden">
        <div className="absolute inset-0">
          <Image src="/images/campus-evening.jpg" alt="Plumtree School" fill
                 className="object-cover object-center" priority />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/60 to-black/75" />
        <div className="relative z-10 px-6 pt-20">
          <span className="eyebrow text-gold-300">Our Story</span>
          <h1 className="text-white mt-3 mb-3">About the <em className="italic text-gold-300">Oldprunitians</em></h1>
          <nav aria-label="Breadcrumb"
               className="flex items-center justify-center gap-2 text-xs text-white/55">
            <Link href="/" className="hover:text-gold-400 transition-colors">Home</Link>
            <span>/</span>
            <span>About</span>
          </nav>
        </div>
      </section>

      {/* MISSION */}
      <section className="section bg-cream-100">
        <div className="container-px">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="reveal">
              <span className="eyebrow">Who We Are</span>
              <h2 className="mt-2 mb-4">
                The Association Behind the <em className="italic text-crimson-700">Red Roofs</em>
              </h2>
              <span className="gold-divider-left" />
              <p className="text-earth-500 leading-relaxed mb-4">
                The Oldprunitians Association (OA) is the official alumni body of Plumtree School, 
                a boarding school established in 1902 in Plumtree Town, Matabeleland South Province, Zimbabwe.
              </p>
              <p className="text-earth-500 leading-relaxed mb-4">
                Our mission is threefold: to maintain the bonds of fellowship among former students; 
                to support the school financially and materially; and to mentor current students 
                as they prepare to enter the world.
              </p>
              <p className="text-earth-500 leading-relaxed mb-8">
                With chapters in Harare, Bulawayo, Johannesburg, London, and Sydney, we are a 
                truly global family — bound by shared memory of red tin roofs, red Kalahari dust, 
                rugby mornings and lifelong friendships.
              </p>
              <div className="grid grid-cols-2 gap-3">
                {STATS.map((s) => (
                  <div key={s.label}
                       className="bg-cream-200 rounded-xl p-4 text-center border border-cream-300">
                    <div className="font-serif text-2xl font-bold text-crimson-700">{s.num}</div>
                    <div className="text-xs font-bold tracking-widest uppercase text-earth-400 mt-1">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="reveal relative" data-delay="150">
              <div className="relative h-[480px] rounded-2xl overflow-hidden shadow-card-lg">
                <Image src="/images/hero.jpg" alt="Plumtree aerial" fill
                       className="object-cover" sizes="(max-width:1024px)100vw,50vw" />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-charcoal text-white rounded-2xl p-6
                              shadow-card-lg max-w-xs">
                <PlumtreeLogo className="w-12 h-12 mb-3" />
                <div className="font-serif text-lg font-semibold text-gold-300">Fortis et Fidelis</div>
                <div className="text-xs text-white/60 mt-1">Brave and Faithful — our motto since 1902</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HOUSES */}
      <section className="section bg-charcoal">
        <div className="container-px">
          <SectionHeader eyebrow="School Houses" title={<>The Four <em className="italic text-gold-400">Houses</em></>}
            body="Every student belongs to one of four historic houses — the foundation of Plumtree's community spirit." light />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {KNOWLEDGE_BASE.houses.map((h, i) => {
              const colours: Record<string,string> = {
                Blue:"#1d4ed8", Red:"#b91c1c", Green:"#15803d", Yellow:"#ca8a04"
              };
              return (
                <div key={h.name}
                     className="reveal bg-white/5 border border-white/8 rounded-2xl p-6
                                hover:border-gold-500/40 transition-all duration-300"
                     data-delay={String(i*80)}>
                  <div className="w-12 h-12 rounded-full mb-4 flex items-center justify-center
                                  border-2 border-white/20"
                       style={{ backgroundColor: colours[h.colour] + "33",
                                borderColor:      colours[h.colour] + "66" }}>
                    <div className="w-5 h-5 rounded-full" style={{ backgroundColor: colours[h.colour] }} />
                  </div>
                  <h4 className="text-white font-serif mb-1">{h.name}</h4>
                  <div className="text-xs text-gold-400 font-bold tracking-wider uppercase mb-3">
                    Est. {h.established}
                  </div>
                  <p className="text-sm text-white/60 leading-relaxed">{h.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* COMMITTEE */}
      <section className="section bg-cream-100">
        <div className="container-px">
          <SectionHeader eyebrow="2024 Executive Committee"
            title={<>Your <em className="italic text-crimson-700">Leadership</em></>}
            body="Elected volunteer members who serve the Oldprunitians community." />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {COMMITTEE.map((m, i) => (
              <div key={m.name} className="reveal text-center group" data-delay={String(i*60)}>
                <div className="relative w-24 h-24 mx-auto mb-3 rounded-full overflow-hidden
                                border-2 border-cream-200 group-hover:border-gold-400
                                transition-colors duration-300 shadow-card">
                  <Image src={m.avatar} alt={m.name} fill
                         className="object-cover transition-transform duration-500 group-hover:scale-105"
                         sizes="96px" />
                </div>
                <div className="font-semibold text-sm text-charcoal">{m.name}</div>
                <div className="text-xs font-bold text-crimson-700 mt-0.5">{m.role}</div>
                <div className="text-xs text-earth-400 mt-0.5">{m.year}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* VALUES */}
      <section className="section bg-cream-200">
        <div className="container-px">
          <SectionHeader eyebrow="What We Stand For"
            title={<>Our <em className="italic text-crimson-700">Values</em></>} />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon:"🎓", num:"01", title:"Academic Excellence", body:"We believe education is the foundation of everything. We fund bursaries, mentor students, and celebrate academic achievement at Plumtree." },
              { icon:"🤝", num:"02", title:"Brotherhood & Sisterhood", body:"The bonds formed at Plumtree are for life. We nurture those connections through reunions, chapters and digital communities." },
              { icon:"🌿", num:"03", title:"Service to School & Community", body:"Every Oldprunitian has a duty to give back — whether through time, treasure or talent — to Plumtree and to Zimbabwe." },
            ].map((v, i) => (
              <div key={v.title} className="reveal" data-delay={String(i*100)}>
                <div className="font-serif text-6xl font-bold text-crimson-700 opacity-15 leading-none mb-1">
                  {v.num}
                </div>
                <div className="text-3xl mb-3">{v.icon}</div>
                <h4 className="mb-3">{v.title}</h4>
                <p className="text-earth-500 leading-relaxed text-sm">{v.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* JOIN CTA */}
      <section className="section-sm bg-crimson-700 text-center">
        <div className="container-px text-white">
          <PlumtreeLogo className="w-16 h-16 mx-auto mb-5" />
          <h2 className="text-white mb-4">
            Proud to be an <em className="italic text-gold-300">Oldprunitian?</em>
          </h2>
          <p className="text-white/70 max-w-lg mx-auto mb-7 leading-relaxed">
            Register your details, connect with your year group, and be part of the family that keeps 
            the Plumtree flame burning bright.
          </p>
          <Link href="/contact" className="btn btn-gold btn-lg">Register as a Member</Link>
        </div>
      </section>
    </>
  );
}
