import { NEWS_ARTICLES } from "@/lib/data";

export default function sitemap() {
  const base = "https://oldprunitians.org.zw";
  const now  = new Date().toISOString();

  const staticPages = [
    { url: `${base}/`,               lastModified: now, changeFrequency: "weekly"  as const, priority: 1.0 },
    { url: `${base}/about`,          lastModified: now, changeFrequency: "monthly" as const, priority: 0.8 },
    { url: `${base}/knowledge-base`, lastModified: now, changeFrequency: "monthly" as const, priority: 0.8 },
    { url: `${base}/gallery`,        lastModified: now, changeFrequency: "monthly" as const, priority: 0.7 },
    { url: `${base}/news`,           lastModified: now, changeFrequency: "weekly"  as const, priority: 0.9 },
    { url: `${base}/contact`,        lastModified: now, changeFrequency: "yearly"  as const, priority: 0.6 },
  ];

  const newsPages = NEWS_ARTICLES.map((a) => ({
    url:             `${base}/news/${a.slug}`,
    lastModified:    new Date(a.date).toISOString(),
    changeFrequency: "never" as const,
    priority:        0.6,
  }));

  return [...staticPages, ...newsPages];
}
