// src/lib/data.ts  —  All static site data

export const SITE = {
  name:        "The Oldprunitians Association",
  short:       "Oldprunitians",
  school:      "Plumtree School",
  founded:     "1902",
  tagline:     "Fortis et Fidelis — Brave & Faithful",
  description: "The official alumni association of Plumtree School, Zimbabwe. Connecting generations of proud Oldprunitians across the globe.",
  email:       "secretary@oldprunitians.org.zw",
  phone:       "+263 28 2441 000",
  address:     "Plumtree School, Plumtree Town, Matabeleland South, Zimbabwe",
  socials: {
    facebook:  "https://facebook.com/oldprunitians",
    twitter:   "https://twitter.com/oldprunitians",
    instagram: "https://instagram.com/oldprunitians",
    whatsapp:  "https://wa.me/26328244100",
  },
};

export const NAV_LINKS = [
  { label: "Home",           href: "/" },
  { label: "About",          href: "/about" },
  {
    label: "Knowledge Base", href: "/knowledge-base",
    children: [
      { label: "School History",     href: "/knowledge-base#history" },
      { label: "Notable Alumni",     href: "/knowledge-base#alumni" },
      { label: "Houses & Traditions",href: "/knowledge-base#traditions" },
      { label: "Sports Legacy",      href: "/knowledge-base#sports" },
    ],
  },
  { label: "Gallery",        href: "/gallery" },
  { label: "Latest News",    href: "/news" },
  { label: "Contact",        href: "/contact" },
];

export const STATS = [
  { num: "1902",  label: "Year Founded" },
  { num: "5,000+",label: "Living Alumni" },
  { num: "122",   label: "Years of Excellence" },
  { num: "6",     label: "Continents Represented" },
];

export const NEWS_ARTICLES = [
  {
    id: 1,
    slug: "annual-reunion-2024",
    category: "Events",
    title: "Annual Old Boys Reunion 2024 — Victoria Falls",
    excerpt: "This year's landmark gathering returns to the Smoke That Thunders. Over 400 Oldprunitians are expected at the Elephant Hills Resort, July 12–14. Registration is now open.",
    date: "2024-05-15",
    author: "Sekuru Ndlovu",
    image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=800&q=80&fit=crop",
    tags: ["Reunion", "Victoria Falls", "2024"],
    featured: true,
  },
  {
    id: 2,
    slug: "bursary-fund-launched",
    category: "Education",
    title: "Oldprunitians Bursary Fund: $50,000 Target for 2024/25",
    excerpt: "Our Education Committee has launched a major fundraising drive to support academically gifted students who would otherwise be unable to attend Plumtree School.",
    date: "2024-04-28",
    author: "Grace Moyo",
    image: "https://images.unsplash.com/photo-1523805009345-7448845a9e53?w=800&q=80&fit=crop",
    tags: ["Bursary", "Education", "Fundraising"],
    featured: true,
  },
  {
    id: 3,
    slug: "rugby-legacy-documentary",
    category: "Sport",
    title: "New Documentary Celebrates Plumtree's Rugby Dynasty",
    excerpt: "A feature-length film charting Plumtree's unparalleled rugby tradition — from the 1960s golden era to present day — premieres in Bulawayo next month.",
    date: "2024-04-10",
    author: "Thandeka Sibanda",
    image: "https://images.unsplash.com/photo-1551958219-acbc608c6377?w=800&q=80&fit=crop",
    tags: ["Rugby", "Documentary", "Heritage"],
    featured: false,
  },
  {
    id: 4,
    slug: "infrastructure-development",
    category: "School",
    title: "New Science Block: Ground-Breaking Ceremony Held",
    excerpt: "Oldprunitians donated over $180,000 toward a state-of-the-art science laboratory block. Ground was broken on 1 March 2024 and completion is expected by December.",
    date: "2024-03-05",
    author: "Principal M. Dube",
    image: "https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=800&q=80&fit=crop",
    tags: ["Infrastructure", "Science", "Development"],
    featured: false,
  },
  {
    id: 5,
    slug: "alumni-feature-dr-nkomo",
    category: "Alumni Spotlight",
    title: "Dr. Sipho Nkomo: From Plumtree to World Health Organisation",
    excerpt: "We profile Class of 1988 alumnus Dr. Sipho Nkomo, now Senior Advisor at the WHO Geneva, whose journey began in Plumtree's biology labs.",
    date: "2024-02-18",
    author: "Editorial Team",
    image: "https://images.unsplash.com/photo-1518020382113-a7e8fc38eac9?w=800&q=80&fit=crop",
    tags: ["Alumni", "Healthcare", "Profile"],
    featured: false,
  },
  {
    id: 6,
    slug: "zimbabwe-chess-championship",
    category: "Sport",
    title: "Plumtree Wins National Chess Championship — Again",
    excerpt: "For the sixth consecutive year, Plumtree School has taken the national secondary school chess title, with five players selected for Zimbabwe's junior team.",
    date: "2024-01-30",
    author: "Sports Desk",
    image: "https://images.unsplash.com/photo-1564760055775-d63b17a55c44?w=800&q=80&fit=crop",
    tags: ["Chess", "National", "Achievement"],
    featured: false,
  },
];

export const GALLERY_ITEMS = [
  {
    id: 1, category: "Campus",
    title: "Main Block — Aerial View",
    image: "/images/hero.jpg",
    year: "2024",
  },
  {
    id: 2, category: "Campus",
    title: "Campus at Dusk",
    image: "/images/campus-dusk.jpg",
    year: "2024",
  },
  {
    id: 3, category: "Campus",
    title: "Evening Light over the Main Block",
    image: "/images/campus-evening.jpg",
    year: "2024",
  },
  {
    id: 4, category: "Wildlife",
    title: "Elephant Herd, Matobo Hills",
    image: "https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=800&q=80&fit=crop",
    year: "2023",
  },
  {
    id: 5, category: "Events",
    title: "Prize-Giving Day",
    image: "https://images.unsplash.com/photo-1523805009345-7448845a9e53?w=800&q=80&fit=crop",
    year: "2023",
  },
  {
    id: 6, category: "Sport",
    title: "Rugby Finals — Bulawayo",
    image: "https://images.unsplash.com/photo-1551958219-acbc608c6377?w=800&q=80&fit=crop",
    year: "2023",
  },
  {
    id: 7, category: "Nature",
    title: "Zimbabwe Savanna at Sunset",
    image: "https://images.unsplash.com/photo-1504208434309-cb69f4fe52b0?w=800&q=80&fit=crop",
    year: "2022",
  },
  {
    id: 8, category: "Events",
    title: "Old Boys Reunion Dinner",
    image: "https://images.unsplash.com/photo-1540202404-1b927e27fa8b?w=800&q=80&fit=crop",
    year: "2022",
  },
  {
    id: 9, category: "Campus",
    title: "Chapel & Grounds",
    image: "https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=800&q=80&fit=crop",
    year: "2022",
  },
];

export const KNOWLEDGE_BASE = {
  history: [
    { year: "1902", event: "Plumtree School founded by the British South Africa Company, initially as a school for European settler children in Matabeleland." },
    { year: "1920s", event: "The iconic main block — now the centrepiece of campus — constructed in the Cape Dutch colonial style with its distinctive red corrugated iron roof." },
    { year: "1953", event: "School opens its doors to all races, becoming one of the first integrated boarding schools in the region." },
    { year: "1960s", event: "Rugby golden era begins. Plumtree wins its first national championship, establishing a dynasty that continues today." },
    { year: "1980", event: "Zimbabwe gains independence. Plumtree School reaffirms its commitment to academic excellence and national development." },
    { year: "1985", event: "The Oldprunitians Association formally registered, uniting alumni across Zimbabwe and the diaspora." },
    { year: "2002", event: "Centenary celebrations held, with 2,000 alumni returning to campus for a historic gathering." },
    { year: "2024", event: "School celebrates 122 years. Science block construction begins, funded by Oldprunitians worldwide." },
  ],
  houses: [
    { name: "Rhodes House",   colour: "Blue",   established: "1902", description: "The original house, traditionally known for academic and chess excellence." },
    { name: "Beit House",     colour: "Red",    established: "1912", description: "Named for the philanthropist Alfred Beit. Strong rugby and athletics tradition." },
    { name: "Jameson House",  colour: "Green",  established: "1925", description: "Home of many of Plumtree's most decorated athletics and cricket champions." },
    { name: "Milton House",   colour: "Yellow", established: "1938", description: "Named after early Rhodesian poet-statesman. Arts, drama and debating powerhouse." },
  ],
  notableAlumni: [
    { name: "Dr. Joshua Nkomo",        year: "1943", field: "Politics",   note: "Father of Zimbabwe Nationalism; Vice President of Zimbabwe." },
    { name: "Lt. Gen. Solomon Mujuru", year: "1965", field: "Military",   note: "Commander of Zimbabwe National Army and liberation war hero." },
    { name: "Dr. Matshobana Ncube",    year: "1978", field: "Medicine",   note: "Pioneer cardiac surgeon; trained at Oxford and Johns Hopkins." },
    { name: "Gus Nkomo",               year: "1982", field: "Sport",      note: "Former Zimbabwe national football captain; African Cup of Nations." },
    { name: "Thandi Mudede",           year: "1989", field: "Law",        note: "Registrar-General of Zimbabwe; legal scholar and administrator." },
    { name: "Brian Chikwanha",         year: "1994", field: "Diplomacy",  note: "Zimbabwean Ambassador to the European Union." },
  ],
};

export const COMMITTEE = [
  { name: "Cde. Musa Ndiweni",  role: "President",            year: "Class of 1985", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80&fit=crop&crop=face" },
  { name: "Mrs. Grace Sibanda", role: "Secretary General",    year: "Class of 1991", avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=200&q=80&fit=crop&crop=face" },
  { name: "Mr. T. Dube",        role: "Treasurer",            year: "Class of 1988", avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&q=80&fit=crop&crop=face" },
  { name: "Dr. N. Moyo",        role: "Education Chair",      year: "Class of 1993", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80&fit=crop&crop=face" },
  { name: "Engr. B. Ncube",     role: "Infrastructure Chair", year: "Class of 1996", avatar: "https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?w=200&q=80&fit=crop&crop=face" },
  { name: "Adv. S. Khumalo",    role: "Legal Advisor",        year: "Class of 1999", avatar: "https://images.unsplash.com/photo-1552058544-f2b08422138a?w=200&q=80&fit=crop&crop=face" },
];

export type NewsArticle  = typeof NEWS_ARTICLES[number];
export type GalleryItem  = typeof GALLERY_ITEMS[number];
