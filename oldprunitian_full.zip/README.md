# 🏫 The Oldprunitians Association Website

**Official alumni website for Plumtree School, Zimbabwe**  
*Fortis et Fidelis — Brave and Faithful*

---

## 🌍 Live Site

Once deployed: **https://`<your-github-username>`.github.io/oldprunitian/**

---

## 🗂 Project Structure

```
oldprunitian/
├── public/
│   ├── images/
│   │   ├── hero.jpg              ← PLUMTREE_SCHOOL_1 (aerial main block)
│   │   ├── campus-dusk.jpg       ← PLUMTREE_SCHOOL_2
│   │   └── campus-evening.jpg    ← PLUMTREE_SCHOOL_3
│   └── favicon.svg
│
├── src/
│   ├── app/
│   │   ├── layout.tsx            ← Root layout (Navbar + Footer + SEO)
│   │   ├── page.tsx              ← Homepage (hero with school photo)
│   │   ├── not-found.tsx         ← 404 page
│   │   ├── sitemap.ts            ← SEO sitemap
│   │   ├── robots.ts
│   │   ├── about/page.tsx        ← About Us
│   │   ├── knowledge-base/page.tsx ← History, Alumni, Houses, Sport
│   │   ├── gallery/page.tsx      ← Photo Gallery
│   │   ├── news/
│   │   │   ├── page.tsx          ← News listing
│   │   │   └── [slug]/page.tsx   ← Individual article
│   │   └── contact/page.tsx      ← Contact form (Web3Forms)
│   │
│   ├── components/
│   │   ├── Navbar.tsx            ← Responsive nav with dropdowns
│   │   ├── Footer.tsx            ← Footer with links & social
│   │   ├── PlumtreeLogo.tsx      ← SVG school crest
│   │   ├── SectionHeader.tsx     ← Reusable heading component
│   │   └── NewsCard.tsx          ← News article card
│   │
│   ├── lib/
│   │   └── data.ts               ← All site content & dummy data
│   │
│   └── styles/
│       └── globals.css           ← Tailwind + custom CSS
│
├── .github/workflows/deploy.yml  ← Auto GitHub Pages deployment
├── next.config.ts                ← Static export config
├── tailwind.config.ts
└── package.json
```

---

## 🚀 Quick Start (Local Development)

### Prerequisites
- **Node.js** v18 or v20
- **npm** v9+
- **Git**

### 1. Clone the repository

```bash
git clone https://github.com/<your-username>/oldprunitian.git
cd oldprunitian
```

### 2. Install dependencies

```bash
npm install
```

### 3. Start development server

```bash
npm run dev
```

Open **http://localhost:3000** in your browser. 🎉

---

## 🌐 Deploying to GitHub Pages

### Step 1 — Create GitHub repository

```bash
# In your project folder
git init
git add .
git commit -m "feat: initial Oldprunitians website"
git branch -M main
git remote add origin https://github.com/<your-username>/oldprunitian.git
git push -u origin main
```

### Step 2 — Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** → **Pages** (left sidebar)
3. Under **Source** select: **GitHub Actions**
4. Click **Save**

### Step 3 — Push to trigger deployment

```bash
git push origin main
```

The GitHub Action (`deploy.yml`) will automatically:
- Install dependencies
- Build the static Next.js export (`npm run build`)
- Deploy the `out/` folder to GitHub Pages

Your site will be live at: `https://<your-username>.github.io/oldprunitian/`

> **Note:** If deploying to a sub-path, set `basePath: "/oldprunitian"` in `next.config.ts`.

---

## 📬 Contact Form Setup (Web3Forms — Free)

The contact form uses **Web3Forms** — a free, no-backend form service. No server needed!

### Steps:
1. Visit **https://web3forms.com** and sign up for free
2. Get your **Access Key** (tied to your email)
3. Open `src/app/contact/page.tsx`
4. Find this line:
   ```html
   <input type="hidden" name="access_key" value="YOUR_WEB3FORMS_KEY_HERE" />
   ```
5. Replace `YOUR_WEB3FORMS_KEY_HERE` with your actual key
6. Push to GitHub — form submissions will arrive in your inbox

> Web3Forms free plan: 250 submissions/month. Upgrade for more.

---

## 🎨 Design System

### Colour Palette
| Token          | Hex       | Usage                          |
|----------------|-----------|--------------------------------|
| `crimson-700`  | `#8B1A1A` | Primary (school brand, buttons)|
| `gold-400/500` | `#C9A040` | Accent, highlights, dividers   |
| `forest-600`   | `#1E3B2F` | Dark sections, tags            |
| `cream-100`    | `#F7F3EC` | Page background                |
| `charcoal`     | `#1A1A18` | Dark backgrounds, footer       |
| `earth-500`    | `#7a5c3a` | Body text                      |

### Typography
- **Headings:** Playfair Display (Google Fonts) — elegant serif
- **Body:** Source Sans 3 (Google Fonts) — clean, readable sans-serif

### Pages
| Page            | Path              | Description                       |
|-----------------|-------------------|-----------------------------------|
| Homepage        | `/`               | Hero, campus photos, news, alumni |
| About           | `/about`          | Mission, committee, values, houses|
| Knowledge Base  | `/knowledge-base` | History, notable alumni, sport    |
| Gallery         | `/gallery`        | Campus + events photo grid        |
| News            | `/news`           | Article listing                   |
| News Article    | `/news/[slug]`    | Full article with sidebar         |
| Contact         | `/contact`        | Web3Forms contact form            |
| 404             | (auto)            | Custom not-found page             |

---

## ✏️ Content Editing

All site content (news, alumni, committee, history, gallery items) lives in one file:

```
src/lib/data.ts
```

Edit this file to update:
- `NEWS_ARTICLES` — add/edit news articles
- `GALLERY_ITEMS` — add gallery photos
- `KNOWLEDGE_BASE.history` — add timeline events
- `KNOWLEDGE_BASE.notableAlumni` — add alumni
- `COMMITTEE` — update committee members
- `SITE` — update contact details, social links

After editing, commit and push — the site redeploys automatically.

---

## 📸 Replacing/Adding Photos

Place new images in `public/images/` then reference them in `data.ts` or page files:

```tsx
// For local images:
<Image src="/images/my-photo.jpg" alt="Description" fill />

// For Unsplash:
<Image src="https://images.unsplash.com/photo-ID?w=800&q=80" ... />
```

---

## 🛠 Available Scripts

```bash
npm run dev    # Start development server (localhost:3000)
npm run build  # Build static export to /out folder
npm run start  # Preview the production build
npm run lint   # Run ESLint checks
```

---

## 🔧 Tech Stack

| Technology        | Purpose                          |
|-------------------|----------------------------------|
| **Next.js 14**    | React framework (App Router)     |
| **TypeScript**    | Type-safe development            |
| **Tailwind CSS**  | Utility-first styling            |
| **Web3Forms**     | Contact form submissions (free)  |
| **GitHub Pages**  | Static site hosting (free)       |
| **GitHub Actions**| CI/CD automatic deployment       |

---

## ✅ Accessibility & SEO

- Semantic HTML (`<nav>`, `<main>`, `<article>`, `<aside>`, `<section>`)
- ARIA labels on all interactive elements
- `alt` text on all images
- Focus-visible styles for keyboard navigation
- Full Open Graph + Twitter Card metadata on every page
- Auto-generated `sitemap.xml` and `robots.txt`
- Responsive from 320px to 4K

---

## 📄 License

© The Oldprunitians Association. All rights reserved.  
Built with pride for Plumtree School 🇿🇼

*Fortis et Fidelis*
